import "./Special.css"

import { Navigation, Pagination, A11y, Autoplay} from 'swiper/modules';
// import { Swiper, SwiperSlide } from 'swiper/react';

// import 'swiper/css';
// import 'swiper/css/navigation';
// import 'swiper/css/pagination';
import { getSpecial } from "../data/repository";
import { FaArrowRightLong } from "react-icons/fa6";
import { PiCornersOutLight } from "react-icons/pi";
import React, {useState, useEffect} from 'react';
import axios from "axios";



function Special(props) {
  const [isLoaded, setIsLoaded] = useState(false);
  const [error, setError] = useState(null);
  const [specials, setSpecials] = useState([]);

  const refreshSpecials = async () => {
    setIsLoaded(false);
    setError(null);
    // Using Axios with async.
    try {
      const result = await axios.get("http://localhost:4000/api/specials");
      setSpecials(result.data);
    } catch(e) {
      setError(e);
    } finally {
      setIsLoaded(true);
    }
  };


  const discountRate = (Math.floor(Math.random() * 4) + 1)*10;

  useEffect(() => {
    refreshSpecials();
  }, []);

  return (
      <div className="special-container">
        <div>
        <div className = "special-heading">
						<h1>Weekly Deals Special</h1>
					</div>
        <div class = "swiper">
          {/* <Swiper
            // install Swiper modules
            modules={[Navigation, Pagination, A11y, Autoplay]}
            spaceBetween={50}
            slidesPerView={1}
            navigation
            pagination={{ clickable: true }}
						loop={true}
						autoplay={{delay: 3000}}
            onSwiper={(swiper) => console.log(swiper)}
            onSlideChange={() => console.log('slide change')}
          >
            <SwiperSlide><img src = "https://carbonliteracy.com/wp-content/uploads/2024/02/nrd-D6Tu_L3chLE-unsplash-scaled-e1708522758951-2048x1321.jpg?fbclid=IwZXh0bgNhZW0CMTAAAR28Qw9mz98YLLkIGtvAvWcwu2KH_iGg4s3V62VMAEqmwnpgRN2DoAb2gqk_aem_AQwfskSoFJ_uMsbA32hxpwPXo7xWQfS8mjRIdyYPwzKRyMikMj8Ml1OYEzYn8__bDxfNg40NPaX4hcBC6ZqUcqqw" alt=""/></SwiperSlide>
            <SwiperSlide><img src = "https://static.wixstatic.com/media/nsplsh_2d667457666f68746a4e77~mv2_d_3920_5928_s_4_2.jpg/v1/fill/w_438,h_661,al_c,q_80,usm_0.66_1.00_0.01,enc_auto/nsplsh_2d667457666f68746a4e77~mv2_d_3920_5928_s_4_2.jpg?fbclid=IwZXh0bgNhZW0CMTAAAR0bUk-O7HWjuWaL0WFUSOhlN-8Gl40kGl07LqS0n-j8nh1Cj_rMC1opETk_aem_AQy5OZtjXzodUt6gdvWZH1oE5mih1LqJ-X4YzCMqJo2kfZtetykjaQGNKuvH92DltFRa6jog5-JKX_DcvSIe2mBw" alt=""/></SwiperSlide>
            <SwiperSlide><img src = "https://www.zenandtheartofbeinginparis.com/wp-content/uploads/2019/07/thomas-le-pRJhn4MbsMM-unsplash-1140x1710.jpg?fbclid=IwZXh0bgNhZW0CMTAAAR1WHeRPG906MXxpxOma8_FlSJRUaX_S3Y9KQDlGEtMZZIW1d6DF2TXFhzg_aem_AQw9DgFIoCeLKEOgBMugTSCp45Np2djQHG49HBuchYvRPevgmdfcCSHVv35R_iPFdLiuh1mdVmbxi3gVp8XevHnp" alt=""/></SwiperSlide>
            <SwiperSlide><img src = "https://cdn.shopify.com/s/files/1/1622/8005/files/dovile-ramoskaite-xX9SmqQCbFY-unsplash_2048x2048.jpg?v=1685330275&fbclid=IwZXh0bgNhZW0CMTAAAR1Neg_8SFZ690lXucvknxLDZ-ENLQDjg2VEu6_kEqTzILNq-oMpNYJRBnE_aem_AQwONHpAf0TDbgY68OsovY5PXvJkx4rVsA94u_Ol268bPwv7N0orsc9_3DQBiatATsXXzJiMrf_3p9OgdG3myItm" alt=""/></SwiperSlide>
          </Swiper> */}
        </div>
        
        <div class = "heading">
            <h1>Browse our hottest Deals</h1>
        </div>
        <div class = "categories-container">
          {specials.map((item) => (
                <div class = "box-deal">
                <img src={item.imageSrc} alt={item.name}/>
                <h2>{item.name}</h2>
                <span>Discount {discountRate}%</span>
                <div className = "discount-info">
                  <p style={{ textDecoration: 'line-through' }}>${  item.price}</p>
                  <FaArrowRightLong id = "arrow-icon"/>
                  <p style={{ color: "red" }}> ${(item.price * (1 - discountRate/100)).toFixed(2)}</p>
                </div>
                
            </div>
            ))}
        </div>
            
        <div class = "about-text">
          <span>Check out small scale farming in the About Page</span>
        </div>
  		</div>
      </div>
    );
  }
  
  export default Special;