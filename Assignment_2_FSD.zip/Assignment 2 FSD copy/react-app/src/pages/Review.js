import React, {useEffect, useState} from 'react';
import './ReviewStyles.css';
import axios from "axios";
import Comment from "../fragments/Comment.js";

function Review(props){
    const reviews = props.reviews;
    // const [items, setItems] = useState([]);
    const [isLoaded, setIsLoaded] = useState(false);
    const [error, setError] = useState(null);
    let filteredReview = [];


    const reviewFilter = () => {
      filteredReview = reviews.filter((review) => parseInt(review.item_id) === parseInt(props.itemID));
    };

    // useEffect(() => {
    //     refreshReviews();
    // }, []);
    reviewFilter();
    return(
        <div className='review-wrapper'>
            <div className='review-list'>
                {
                  filteredReview.map((review, index) => (
                    <Comment key={index} review={review}/>
                  ))
                }
            </div>
            
        </div>
    );

}

export default Review;