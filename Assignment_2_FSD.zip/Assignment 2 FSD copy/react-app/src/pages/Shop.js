import React, {useState, useEffect} from 'react'
import "./ShopStyles.css"
import ItemList from '../fragments/ItemList';
import { IoIosSearch } from "react-icons/io";
import axios from "axios";


function Shop(){
    const [items, setItems] = useState([]);
    const [searchedItems, setSearchedItems] = useState([]);
    const [title, setTitle] = useState("ALL");
    const [filterOption, setFilterOption] = useState("select option");
    const [filterValue, setFilterValue] = useState(0);
    const [isLoaded, setIsLoaded] = useState(false);
    const [error, setError] = useState(null);

    const refreshItems = async () => {
        setIsLoaded(false);
        setError(null);
        // Using Axios with async.
        try {
          const result = await axios.get("http://localhost:4000/api/items");
          setItems(result.data);
          setSearchedItems(result.data);
        } catch(e) {
          setError(e);
        } finally {
          setIsLoaded(true);
        }
    };
    const Search = (event) => {
        event.preventDefault();
        const keyword = event.target.search.value;
        if(keyword === "") return;
        
        const filteredItems = items.filter(item => item.name.toLowerCase().includes(keyword.toLowerCase()));

        if(filteredItems.length === 0) setTitle("No result")
        else{
            setTitle(`Searched by: \"${keyword}\" (${filteredItems.length} items founded)`);
        }
        setSearchedItems(filteredItems);
    }
    const SelectOption = (event) => {
        const option = event.target.textContent;
        setFilterOption(option);
    }
    const handleInputChange = (event) => {
        const value = event.target.value;
        // Copy fields.
        let temp = filterValue;

        // Update field and state.
        temp = value;
        setFilterValue(temp);
    }
    const applyFilter = (event) => {
        event.preventDefault();
        let filteredItems;
        if(filterOption === "equal to"){
            filteredItems = items.filter(item => item.price.toString() === filterValue);
        }
        else if(filterOption === "less than"){
            filteredItems = items.filter(item => parseFloat(item.price) < parseFloat(filterValue));
        }
        else if(filterOption === "more than"){  
            filteredItems = items.filter(item => parseFloat(item.price) > parseFloat(filterValue));
        }
        else return;
        
        setSearchedItems(filteredItems);
    }
    const CategoryFilter=(event)=>{
        event.preventDefault();
        const selectedCategory = event.target.textContent;
        switch(selectedCategory) {
            case 'All':
                setSearchedItems(items);
                setTitle("ALL");
                break;
            case 'Red':
                setSearchedItems(items.filter(item => item.category === "red"));
                setTitle("Red");
                break;
            case "Yellow / Orange":
                setSearchedItems(items.filter(item => item.category === "yellow"));
                setTitle("Yello / Orange");
                break;
            case 'Green':
                setSearchedItems(items.filter(item => item.category === "green"));
                setTitle("Green");
                break;
            case 'Blue / Purple':
                setSearchedItems(items.filter(item => item.category === "blue"));
                setTitle("Blue / Purple");
                break;
            case 'White':
                setSearchedItems(items.filter(item => item.category === "white"));
                setTitle("White");
                break;
            default:
            
                break;
        }
    }
    useEffect(() => {
        refreshItems();
    }, []);

    return(
        <div>
            <h1 id="shop-title"> { title } </h1>
            <hr id = "line"></hr>
            <div className='content'>
                <div className="side-bar">
                    <form onSubmit={ Search }>
                        <div className='search-box'>
                            <input type = "text" placeholder="Search" name="search" id="search"/>
                            <button type = "submit" id="search-icon">
                                <IoIosSearch />
                            </button>
                        </div>
                    </form>
                    <h2>Filter:</h2>
                    <hr/>
                    <div className="filter">
                        <div className = "filter-inner">
                        <h4>Price:</h4>
                        <div class="dropdown">
                            <span class="dropbtn">{filterOption}</span>
                            <div class="dropdown-content">
                                <p onClick = {SelectOption}>equal to</p>
                                <p onClick = {SelectOption}>less than</p>
                                <p onClick = {SelectOption}>more than</p>
                            </div>
                        </div> 
                        <p>$</p>
                        <input type='number' value={filterValue} onChange={handleInputChange}/>
                        </div>
                        
                        <button onClick={applyFilter}>Apply</button>
                    </div>
                    
                    
                    <div className="category-list">
                        <h2>Category</h2> 
                        <hr/>
                        <ul>
                            <li onClick = {CategoryFilter} >All</li>
                            <li onClick = {CategoryFilter} style={{ color: "red" }}>Red</li>
                            <li onClick = {CategoryFilter} style={{ color: "orange" }}>Yellow / Orange</li>
                            <li onClick = {CategoryFilter} style={{ color: "green" }}>Green</li>
                            <li onClick = {CategoryFilter} style={{ color: "indigo" }}>Blue / Purple</li>
                            <li onClick = {CategoryFilter} style={{ color: "white" }}>White</li>
                            
                        </ul>
                    </div>
                </div>
                <ItemList items = {searchedItems}/>
            </div>
            

            
        </div>
        
    );
}

export default Shop;