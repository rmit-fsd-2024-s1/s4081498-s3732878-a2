import "./About.css"
import React, { useState } from 'react';
// import Swiper core and required modules
import { Navigation, Pagination, A11y } from 'swiper/modules';

// import { Swiper, SwiperSlide } from 'swiper/react';

// Import Swiper styles
// import 'swiper/css';
// import 'swiper/css/navigation';
// import 'swiper/css/pagination';
// import 'swiper/css/scrollbar';

function About() {

  const ContentChangeBox = ({ selectedVegetable, contents }) => {
    return (
      <div>
        <h2>{selectedVegetable}</h2>
        <p>{contents[selectedVegetable]}</p>
      </div>
    );
  };
  
  // Component for the sidebar with category selection
  const Sidebar = ({ categories, selectedCategory, onCategoryChange }) => {
    return (
      <div className="sidebar">
        <h3 style={{color:"brown", textDecoration:"underline"}}>vegetables</h3>
        <ul>
          {categories.map((category) => (
            <li key={category} onClick={() => onCategoryChange(category)} className={selectedCategory === category ? 'active' : ''}>
              {category}
            </li>
          ))}
        </ul>
      </div>
    );
  };
  
  const vegetables = ['Potato', 'Tomato', 'Onion', 'Lemon', 'Chilli'];
  const contents = {
    'Potato': 'To farm potatoes: Choose a sunny location with well-drained soil. Prepare the soil by loosening it and adding organic matter. Plant seed potatoes about 12 inches apart in rows, with eyes facing up, in early spring. Keep the soil consistently moist but not waterlogged. Hill up soil around the plants as they grow to encourage tuber formation. Control weeds and pests. Harvest when the plants flower and the tops start to yellow and die back. Carefully dig up potatoes, being careful not to damage them. Cure potatoes by letting them dry in a cool, dark place for 1-2 weeks before storing.',
    'Tomato': 'To farm tomatoes: Choose a sunny location with well-drained soil. Prepare the soil by adding compost or organic matter. Plant tomato seedlings after the danger of frost has passed, spacing them about 18-24 inches apart. Water regularly, aiming to keep the soil consistently moist but not waterlogged. Mulch around the plants to help retain moisture and suppress weeds. Stake or cage the plants to support their growth and keep fruits off the ground. Fertilize periodically with a balanced fertilizer according to package instructions. Monitor for pests and diseases, taking appropriate action if necessary. Harvest tomatoes when they are fully ripe, typically when they have reached their mature color and firmness. Store tomatoes at room temperature away from direct sunlight for best flavor, but refrigerate if they need to be kept longer.',
    'Onion': 'To farm onions: Choose a location with full sun and well-drained soil. Prepare the soil by adding compost or well-rotted manure to improve fertility. Plant onion sets or seeds in early spring, spacing them about 4-6 inches apart in rows. Plant onion sets about 1 inch deep in the soil, with the pointed end facing up. Keep the soil consistently moist, especially during the early stages of growth. Weed regularly to prevent competition for nutrients and space. Once the tops begin to turn yellow and fall over, stop watering to allow the bulbs to mature. Harvest onions when the tops have dried out and fallen over completely. Carefully lift the onions from the soil and let them cure in a warm, dry place for a few weeks. Once cured, trim the tops and roots and store onions in a cool, dry place for long-term storage',
    'Lemon':'To farm lemons: Choose a location with plenty of sunlight and well-drained soil, preferably slightly acidic. Plant lemon trees in spring or early fall, ensuring they have enough space to spread their roots. Dig a hole slightly larger than the root ball and plant the tree at the same depth it was in the nursery pot. Water deeply and regularly, especially during dry periods, but avoid waterlogging the soil. Mulch around the base of the tree to retain moisture and suppress weeds. Fertilize with a balanced fertilizer formulated for citrus trees, following the instructions on the package. Prune to remove dead or diseased branches and to shape the tree as desired. Protect the tree from frost by covering it or providing additional insulation during cold weather. Monitor for pests and diseases, taking appropriate action if necessary. Harvest lemons when they are fully ripe, typically when they have developed their full color and are slightly soft to the touch.',
    'Chilli': 'To farm spicy chili: Choose the right variety: Select chili pepper varieties known for their spiciness, like habanero, jalapeño, or ghost pepper. Prepare the soil: Ensure well-draining soil with plenty of organic matter. Chili peppers prefer slightly acidic soil with a pH around 6.0 to 6.5. Planting: Start seeds indoors 6-8 weeks before the last frost, then transplant them outdoors after the danger of frost has passed. Plant in a sunny location with spaced-out rows. Watering: Keep the soil consistently moist but not waterlogged. Water deeply once or twice a week, depending on weather conditions. Fertilizing: Use a balanced fertilizer or one with higher phosphorus for fruit development. Apply according to package instructions. Mulching: Mulch around the plants to retain moisture and suppress weeds. Pest and Disease Control: Monitor for pests like aphids and diseases like powdery mildew. Use organic pesticides and fungicides if necessary. Harvesting: Harvest peppers when they reach the desired size and color. The longer they stay on the plant, the hotter they become. Storage: Store harvested peppers in a cool, dry place. They can also be dried, frozen, or pickled for long-term storage. Rotate Crops: To prevent soil depletion and disease buildup, rotate chili peppers with other crops each growing season.',
  };

  const [selectedVegetable, setSelectedVegetable] = useState(vegetables[0]);

  const handleVegetableChange = (vegetable) => {
    setSelectedVegetable(vegetable);
  };
  
  return (
    <div class = 'phytonutrient-farming'>
    <div class = "head"><h1>Phytonutrients in every colors</h1></div>
    {/* <Swiper
      // install Swiper modules
      modules={[Navigation, Pagination, A11y]}
      spaceBetween={50}
      slidesPerView={1}
      loop={true}
      navigation
      pagination={{ clickable: true }}
      onSwiper={(swiper) => console.log(swiper)}
      onSlideChange={() => console.log('slide change')}
    >
      <SwiperSlide>
        <div class = "about-color">
        <img src = "red.jpg" alt=""></img>
        <div class = "about-text">
          <span style={{color: "red"}}>Red</span>
          <p>Rich in the carotenoid lycopene, a potent scavenger of gene-damaging free radicals that seems to protect against prostate cancer as well as heart and lung disease.</p>
          <p>Found in: strawberries, cranberries, raspberries, tomatoes, cherries, apples, beets, watermelon, red grapes, red peppers, red onions</p>                  
          </div>      
        </div>
      </SwiperSlide>
      <SwiperSlide>
        <div class = "about-color">
        <img src = "orange-yellow.jpg" alt=""></img>
        <div class = "about-text">
          <span style={{color: "orange"}}>Orange and yellow</span>
          <p>Provide beta cryptothanxin, which supports intracellular communication and may help prevent heart disease.</p>
          <p>Found in: carrots, sweet potatoes, yellow peppers, oranges, bananas, pineapple, tangerines, mango, pumpkin, apricots, winter squash (butternut, acorn), peaches, cantaloupe, corn.</p>                  
        </div>
        </div>
      </SwiperSlide>
      <SwiperSlide>
        <div class = "about-color">
        <img src = "green.jpg" alt=""></img>
        <div class = "about-text">
          <span style={{color: "green"}}>Green</span>
          <p>These foods are rich in cancer-blocking chemicals like sulforaphane, isothiocyanates, and indoles, which inhibit the action of carcinogens (cancer-causing compounds).</p>
          <p>Found in: spinach, avocados, asparagus, artichokes, broccoli, alfalfa sprouts, kale, cabbage, Brussels sprouts, kiwi fruit, collard greens, green tea, green herbs (mint, rosemary, sage, thyme, and basil).</p>                  
        </div>
        </div>
      </SwiperSlide>
      <SwiperSlide>
        <div class = "about-color">
          <img src = "blue-purple.jpg" alt=""></img>
          <div class = "about-text">
            <span style={{color: "Blue"}}>Blue and purple</span>
            <p>Have powerful antioxidants called anthocyanins believed to delay cellular aging and help the heart by blocking the formation of blood clots.</p>
            <p>Found in: blueberries, blackberries, elderberries, Concord grapes, raisins, eggplant, plums, figs, prunes, lavender, purple cabbage.</p>                  
          </div>
        </div></SwiperSlide>
      <SwiperSlide>
        <div class = "about-color">
          <img src = "white-brown.jpg" alt=""></img>
          <div class = "about-text">
            <span style={{color: "brown"}}>White and brown</span>
            <p>The onion family contains allicin, which has anti-tumor properties. Other foods in this group contain antioxidant flavonoids like quercetin and kaempferol.</p>             
            <p>Found in: onions, cauliflower, garlic, leeks, parsnips, daikon radish, mushrooms.</p>                  
          </div>
        </div>
      </SwiperSlide>
    </Swiper> */}
    <div>
    <div className="small-scale-farming">
      <div className="sidebar-container-farm">
        <Sidebar
          categories={vegetables}
          selectedCategory={selectedVegetable}
          onCategoryChange={handleVegetableChange}
        />
      </div>
      <div className="content-container-farm">
        <h1>Small scale farming for vegetables</h1>
        <ContentChangeBox selectedVegetable={selectedVegetable} contents={contents} />
      </div>
    </div>
    </div>
    
    </div>
  );
}

export default About;