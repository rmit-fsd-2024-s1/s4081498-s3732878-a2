import React from "react";
import { useHistory } from "react-router-dom";

function Home(props) {
  // console.log(props);
  const history = useHistory();

  return (
    <div className="text-center">
      <h1>Home</h1>
      {props.username != null && <h4><strong>Welcome, {props.username}!</strong></h4>}
      <img src="/logo.svg" className="w-50" alt="logo" />

    </div>
  );
}

export default Home;
