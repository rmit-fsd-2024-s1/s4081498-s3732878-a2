// import { FaDisplay } from 'react-icons/fa6';
import './ProfileStyles.css';
import { useRef, useState, useEffect, useLayoutEffect } from 'react';
import { useNavigate } from "react-router-dom";
import { getUser } from '../data/repository';
import axios from "axios";


function Profile(props) {
  
  const inputRef = useRef(null)
  const [image, setImage] = useState("")
  
  const [user, setUser] = useState(getUser());  
  const [userInfo, setUserInfo] = useState({});
  const [isEditing, setIsEditing] = useState(false);
  const [isStrong, setIsStrong] = useState(null);
  const [isCorrectForm, setIsCorrectFoem] = useState(null);
  const [users, setUsers] = useState([]);
  const [isLoaded, setIsLoaded] = useState(false);
  const [error, setError] = useState(null);
  const navigate = useNavigate();


  const handleImgaeClick = () => {
    inputRef.current.click();
  };
  const handleImageChange = (event) => {
    const file =event.target.files[0];
    setImage(event.target.files[0]);
  };
  const handleInputChange = (event) => {
    const name = event.target.name;
    const value = event.target.value;
    // Copy fields.
    const temp = { ...userInfo };

    // Update field and state.
    temp[name] = value;
    setUserInfo(temp);
  }
  const findUserID = () =>{
    for(let i = 0; i < users.length; i++){
      if(users[i].email === user){
        setUserInfo(users[i]);
        break;
      }
    }
  }
  const passwordIsStrong = (password) => {
    let alphabetCount = 0;
    let numberCount = 0;
    let specialCount = 0;

    for (let i = 0; i < password.length; i++) {
        const char = password[i];
        if (/[a-zA-Z]/.test(char)) {
            alphabetCount++;
        } else if (/[0-9]/.test(char)) {
            numberCount++;
        } else {
            specialCount++;
        }
    }
    if(alphabetCount === 0 || numberCount === 0 || specialCount === 0){
        setIsStrong("The password must be a combination of numbers, alphabets, and special characters.");
        return;
    }
    // Check if password is longer than 12
    if(password.length < 12 ){
        setIsStrong("The password must be longer than or equal 12");
        return false;
    }
    // Check if password contains at least one upper letter
    if(password === password.toLowerCase()){
        setIsStrong("The password must contain at least one upper letter");
        return false;
    }
    return true;
}
const checkPhoneNumberForm = (phoneNumber) => {
  const phoneNumberPattern = /^\d{10}$/;
  if(phoneNumberPattern.test(phoneNumber)) return true;
  else {
    setIsCorrectFoem("The phone number must be a 10-digit number.");
    return false;
  }
}
const updateAccount = async (event) => {
    event.preventDefault();
    // Check user put the same value on password input and checkPassword input
    if(!passwordIsStrong(userInfo.password)){
        return;
    }
    if(!checkPhoneNumberForm(userInfo.phoneNumber)){
      return;
    }
    await axios.put(`http://localhost:4000/api/users/${userInfo.user_id}`, userInfo);
    alert("User information is updated.")
}
const removeUser = async () => {
  if(!window.confirm(`Are you sure you want to delete User ${user}?`))
    return;

  // Using Axios with async.
  try {
    await refreshUsers();
  } catch(e) {
    setError(e);
  }
};
const deleteAccount = () => {
  removeUser();
  props.logoutUser();
  navigate("/login");
}
const refreshUsers = async () => {
  setIsLoaded(false);
  setError(null);
  // Using Axios with async.
  try {
    const result = await axios.get("http://localhost:4000/api/users");
    setUsers(result.data);
    } catch(e) {
    setError(e);
    } finally {
      setIsLoaded(true);
    }
};

useEffect(() => {
  if(users.length === 0){
    refreshUsers();
  }
  findUserID();
}, [users])

  return (
    <div className = "profile-box">
    <div class="profile-wrapper">
      <h1>User Profile</h1> 
      <div class = 'text_box'>
        <div className="profile-image" onClick={handleImgaeClick}>
          {image ? <img class = 'img_deg' src = {URL.createObjectURL(image)} alt=""/> : <img class = 'img_deg' src = "./google.png" alt=""/>}
          <input type="file" ref={inputRef} onChange={handleImageChange} style={{display:'none'}}/>
        </div>
        <ul class = 'profile-list'>
          <li><h1> User Information</h1></li>
          <li>Date of joining: {userInfo.date}</li>
          <li>User Name: {userInfo.username}</li>
          <li>
            <form onSubmit={(e) => {
              e.preventDefault();
              setIsEditing(!isEditing);
            }}>
              <label>
                Email Address: {userInfo.email}
              </label> 
            </form>
          </li>
          <li>
          <form onSubmit={(e) => {
              e.preventDefault();
              setIsEditing(!isEditing);
            }}>
              <label>
                Password:
                <input type = "text" required 
                    name="password" id="password"
                    value={userInfo.password} onChange={handleInputChange}/>
              </label>  
            </form>
          </li>
          <li>
            <form onSubmit={(e) => {
              e.preventDefault();
              setIsEditing(!isEditing);
            }}>
              <label>
                Phone Number:{""}
                <input type = "text" inputMode='numberic' required 
                    name="phoneNumber" id="phoneNumber"
                    value={userInfo.phoneNumber} onChange={handleInputChange}/>
              </label>  
            </form>
            
          </li>
          <li>
            <form onSubmit={(e) => {
              e.preventDefault();
              setIsEditing(!isEditing);
            }}>
              <label>
                Home Adress:{""}
                <input type = "text" required 
                    name="address" id="address"
                    value={userInfo.address} onChange={handleInputChange}/>
              </label>
              <div class = 'profile-button'>
              <div className="errorMessage">
                <span>{isStrong}</span>
              </div>
              <div className="errorMessage">
                <span>{isCorrectForm}</span>
              </div>
                <button onClick={updateAccount} id = 'button1'>Save Profile</button>
                <button onClick={deleteAccount} id = 'button2'>Delete Account</button>
              </div> 
            </form>
          </li>
        </ul>
      </div>
    </div> 
    </div>
  );
}

export default Profile;