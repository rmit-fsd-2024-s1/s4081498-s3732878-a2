import React, {useState, useEffect} from "react";
import { getCart, updateCart, getUser, getUserInfo, initCart } from "../data/repository";
import CartCard from '../fragments/CartCard.js';
import "./CartStyles.css";
import { FaCreditCard, FaCcMastercard} from "react-icons/fa6";
import { SiApplepay } from "react-icons/si";
import { RiVisaFill } from "react-icons/ri";
import axios from "axios";




function Cart(props) {

    const [isLoaded, setIsLoaded] = useState(false);
    const [error, setError] = useState(null);
    const [cart, setCart] = useState([]);
    const [totalPrice, setTotalPrice] = useState(0);
    const [totalNumber, setTotalNumber] = useState(0);
    const [isCard, setIsCard] = useState(true);
    const [orderForm, setOrderForm] = useState({cardNumber: "", expiration: "", cvc: "", country: ""});
    const [orderFormA, setOrderFormA] = useState({appleID: "", password: ""});
    const [errorCardNumber, setErrorCardNumber] = useState("");
    const [errorExpiration, setErrorExpiration] = useState("");
    const [errorCVC, setErrorCVC] = useState("");
    const [users, setUsers] = useState([]);
    const [user, setUser] = useState(getUser());
    const [userInfo, setUserInfo] = useState({});

    const refreshCarts = async () => {
        setIsLoaded(false);
        setError(null);
        // Using Axios with async.
        try {
          const result = await axios.get("http://localhost:4000/api/carts");
          setCart(result.data);
        } catch(e) {
          setError(e);
        } finally {
          setIsLoaded(true);
        }
    };
    const refreshUsers = async () => {
        setIsLoaded(false);
        setError(null);
        // Using Axios with async.
        try {
          const result = await axios.get("http://localhost:4000/api/users");
          setUsers(result.data);
          } catch(e) {
          setError(e);
          } finally {
            setIsLoaded(true);
          }
    };
    const findUserID = () =>{
        for(let i = 0; i < users.length; i++){
          if(users[i].email === user){
            setUserInfo(users[i]);
            break;
          }
        }
      }
    const handleInputChange = (event) => {
        const name = event.target.name;
        const value = event.target.value;
        let temp = null;
        if(isCard){
            temp = { ...orderForm };
        }
        else{
            temp = { ...orderFormA };
        }
        // Update field and state.
        temp[name] = value;
        if(isCard){
            setOrderForm(temp);
        }
        else{
            setOrderFormA(temp);
        }
    }
    const getTotalPrice=()=>{
        let tmp = 0;
        cart.forEach((cart) => tmp += (cart.price * cart.quantity));
        setTotalPrice(tmp);
    }
    const getTotalNumber=()=>{
        let tmp = 0;
        cart.forEach((cart) => tmp += cart.quantity);
        setTotalNumber(tmp);
    }
    const removeItem = async (name) =>{
        const item = cart.filter(item => item.name == name);
        await axios.delete(`http://localhost:4000/api/carts/${item[0].item_id}`);
        refreshCarts();
    }
    const quantityPlus = (name) =>{
        const tmp = cart.map(item => {
            if (item.name === name) {
                return { ...item, quantity: item.quantity + 1 };
            }
            return item;
        });
        
        setCart(tmp);
    }
    const quantityMinus = (name) =>{
        const tmp = cart.map(item => {
            if (item.name === name && item.quantity > 1) {
                return { ...item, quantity: item.quantity - 1 };
            }
            return item;
        });
        setCart(tmp);
    }
    const changePaymentMethod = (event) => {
        if(event.target.textContent === "Card"){
            setIsCard(true);
        }
        else{
            setIsCard(false);
        }
    } 
    const isCardNumber = (cardNumber)=>{
        if (!/^\d+$/.test(cardNumber) || cardNumber.length !== 16) {
            setErrorCardNumber("Card number is 16 digit numbers");
          return false;
        }
        setErrorCardNumber("");
        return true;
    }
    const isExpiration=(expiration) => {
        const regex = /^(0[1-9]|1[0-2])\/\d{2}$/;
        if(!regex.test(expiration)){
            setErrorExpiration("Expiration is MM/YY format");
            return false;
        }
        setErrorExpiration("");
        return true;
      }
    const isCVC = (cvc)=>{
        if (!/^\d+$/.test(cvc) || cvc.length != 3) {
            setErrorCVC("CVC is 3 digit numbers");
          return false;
        }
        setErrorCVC("");
        return true;
    }
    const order = (event) => {
        event.preventDefault();
        if(isCard){
            if(!isCardNumber(orderForm.cardNumber)){return;}
            if(!isExpiration(orderForm.expiration)){return;}
            if(!isCVC(orderForm.cvc)){return;}
        }
        if(cart.length === 0){
            alert("Cart is empty!");
            return;
        }
        initCart();
        setCart(getCart());
        alert("Order successfully");
    }
    useEffect(() => {
        getTotalPrice();
        getTotalNumber();
    }, cart);
    useEffect(() => {
        refreshCarts();
        refreshUsers();
    }, []);
    useEffect(() => {
        findUserID();
      }, [users])
  return (
    <div className="cart-wrapper">
        <div className="list">
            {props.username !== null && <h2><strong>{userInfo.username}'s cart</strong></h2>}
            {user.username}
            {cart.map((item, index) => (
                <CartCard key={index} item={item} removeItem = {removeItem}
                quantityPlus = {quantityPlus} quantityMinus = {quantityMinus}/>
            ))}
        </div>
        
        <div className="receipt" style={{ height: isCard ? '510px' : '430px' }}>
            <p id="totalPrice">Total {totalNumber} items</p>
            <p id="totalPrice">Total price: ${totalPrice.toFixed(2)}</p>
            <div className="payment-method">
                <button onClick = {changePaymentMethod}><span><FaCreditCard/></span><span>Card</span></button>
                <button onClick = {changePaymentMethod}><span><SiApplepay/></span> <span>Apple Pay</span> </button>
            </div>
            <form onSubmit={order}>
                { isCard ?
                    <div className = "input-box">
                        <label for="cartNumber">Card number</label>
                        <div className = "card-number">
                            <input type = "number" placeholder="1234 1234 1234 1234" required name="cardNumber" 
                            id="cardNumber" value={orderForm.cardNumber} onChange={handleInputChange}/>
                            <RiVisaFill className="visa-icon"/>
                            <FaCcMastercard className="master-icon"/>
                        </div>
                    <div className="expiration-cvc">
                        <div className = "half-input">
                            <label for="expiration">Expiration</label>
                            <input type = "text" placeholder="MM/YY" required name="expiration" 
                            id="expiration" value={orderForm.expiration} onChange={handleInputChange}/>
                        </div>
                        <div className = "half-input">
                            <label for="expiration">CVC</label>
                            <input type = "number" placeholder="CVC" required name="cvc" 
                            id="cvc" value={orderForm.cvc} onChange={handleInputChange}/>
                        </div>
                    </div>
                    <label for="country">Country</label>
                    <input type = "text" placeholder="Country" required name="country" 
                    id="country" value={orderForm.country} onChange={handleInputChange}/>
                </div>
                :
                <div className="input-box">
                    <label for="apply-id">Apple ID</label>
                    <input type = "text" placeholder="Apple ID" required 
                        name="appleID" id="appleID" value={orderFormA.appleID} onChange={handleInputChange}/>
                    
                    <label for="password">Passsword</label>
                    <input type = "password" placeholder="password" required 
                        name="password" id="password" value={orderFormA.password} onChange={handleInputChange}/>
                </div>
            }
                {errorCardNumber !== "" &&
                    <div className="errorMessage">
                        <span>{errorCardNumber}</span>
                    </div>
                }
                {errorExpiration !== "" &&
                            <div className="errorMessage">
                                <span>{errorExpiration}</span>
                            </div>
                }
                {errorCVC !== "" &&
                    <div className="errorMessage">
                        <span>{errorCVC}</span>
                    </div>
                }
                <button type = "submit" id="order-button">Order</button>
            </form>
        </div>
    </div>
  );
}

export default Cart;
