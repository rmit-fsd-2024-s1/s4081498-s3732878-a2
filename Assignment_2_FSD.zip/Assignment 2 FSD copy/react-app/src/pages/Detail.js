import React, {useEffect, useState} from 'react';
import { useParams } from 'react-router-dom';
import './DetailStyles.css';
import axios from "axios";
import Review from "./Review.js";
import Star from "../fragments/Star.js";



function Detail(props){
    const id = useParams();
    const [itemInfo, setItemInfo] = useState([]);
    const [reviews, setReviews] = useState([]);
    const [quantity, setQuantity] = useState(1);
    const [isLoaded, setIsLoaded] = useState(false);
    const [error, setError] = useState(null); 
    
    const refreshItems = async () => {
        setIsLoaded(false);
        setError(null);
        try {
          const result = await axios.get(`http://localhost:4000/api/items/${id.id}`);
          setItemInfo(result.data);
          } catch(e) {
          setError(e);
          } finally {
            setIsLoaded(true);
          }
     };

    const refreshReviews = async () => {
        setIsLoaded(false);
        setError(null);
        // Using Axios with async.
        try {
          const result = await axios.get("http://localhost:4000/api/reviews");
          setReviews(result.data);
        } catch(e) {
          setError(e);
        } finally {
          setIsLoaded(true);
        }
    };
    
    useEffect(() => {
        refreshItems();
        refreshReviews();
    }, [])


    return(
        <div>
            <div className='detail-wrapper'>
                <div className='item-image'>
                    <img src = {itemInfo.imageSrc}/>
                </div>
                <div className = "item-details">
                    <h2>{itemInfo.name}</h2>
                    <p>{itemInfo.description}</p>
                    <p>${itemInfo.price}</p>
                    <Star itemID = {id.id} refreshReviews = {refreshReviews}/>
                </div>
            </div>
            <h2>Review</h2>
            <div className='review'>
                <Review itemID = {id.id} reviews = {reviews}/>
            </div>
        </div>
    );
}

export default Detail;