import "./SigninStyles.css";
import React, { useState, useEffect} from "react";
import { useNavigate } from "react-router-dom";
import { FaUser } from "react-icons/fa";
import { FaCheck } from "react-icons/fa6";
import { FaPhone } from "react-icons/fa";
import { MdEmail } from "react-icons/md";
import { FaLocationDot } from "react-icons/fa6";
import { PiPassword } from "react-icons/pi";
import axios from "axios";


function Signin(){
    const [fields, setFields] = useState({ username: "", email: "", phoneNumber: "", password: "", checkPassword: "", address: "", date: ""});
    const [isAvailableUser, setIsAvailableUser] = useState(null);
    const [isAvailablePhoneNumber, setIsAvailablePhoneNumber] = useState(null);
    const [isAvailablePassword, setisAvaIlablePassword] = useState(null);
    const [isStrong, setIsStrong] = useState(null);
    const [users, setUsers] = useState([]);
    const [isLoaded, setIsLoaded] = useState(false);
    const [error, setError] = useState(null);
    const navigate = useNavigate();

    const refreshUsers = async () => {
        setIsLoaded(false);
        setError(null);
        // Using Axios with async.
        try {
          const result = await axios.get("http://localhost:4000/api/users");
          setUsers(result.data);
        } catch(e) {
          setError(e);
        } finally {
          setIsLoaded(true);
        }
    };
    // Generic change handler.
    const handleInputChange = (event) => {
        const name = event.target.name;
        const value = event.target.value;
        
        // Copy fields.
        const temp = { ...fields };

        // Update field and state.
        temp[name] = value;
        setFields(temp);
    }
    const checkEmailForm = (email) => {
        const emailPattern = /^[a-zA-Z0-9._%+-]+@gmail.com$/;
        if(emailPattern.test(email)) return true;
        else return false;
    }
    const checkPhoneNumberForm = (phoneNumber) => {
        const phoneNumberPattern = /^\d{10}$/;
        if(phoneNumberPattern.test(phoneNumber)) return true;
        else return false;
    }
    const setDate = () =>{
        const tmp = {...fields};
        const now = new Date();
        const year = now.getFullYear();
        const month = now.getMonth() + 1;
        const day = now.getDate();
        const hours = now.getHours();
        const minutes = now.getMinutes();
        const dateString = `${year}-${month < 10 ? '0' + month : month}-${day < 10 ? '0' + day : day} ${hours < 10 ? '0' + hours : hours}:${minutes < 10 ? '0' + minutes : minutes}`;
        tmp.date = dateString;
        setFields(tmp);
    }
    const passwordIsStrong = (password) => {
        console.log(password);
        let alphabetCount = 0;
        let numberCount = 0;
        let specialCount = 0;

        for (let i = 0; i < password.length; i++) {
            const char = password[i];
            if (/[a-zA-Z]/.test(char)) {
                alphabetCount++;
            } else if (/[0-9]/.test(char)) {
                numberCount++;
            } else {
                specialCount++;
            }
        }
        if(alphabetCount === 0 || numberCount === 0 || specialCount === 0){
            setIsStrong("The password must be a combination of numbers, alphabets, and special characters.");
            return;
        }
        // Check if password is longer than 12
        if(password.length < 12 ){
            setIsStrong("The password must be longer than or equal 12");
            return false;
        }
        // Check if password contains at least one upper letter
        if(password === password.toLowerCase()){
            setIsStrong("The password must contain at least one upper letter");
            return false;
        }
        return true;
    }   
    const createAccount = async (event) => {
        event.preventDefault();
        // Check Email form
        if(!checkEmailForm(fields.email)){
            setIsAvailableUser("The username is must be email form!");
            return;
        }
        // Check if the username is already existed
        const isExist = false;
        for(let i = 0; i < users.length; i++){
            if(users[i].email === fields.email){
                isExist = true;
                break;
            }
        }
        // Check if the phone number follows the correct formmat
        if(!checkPhoneNumberForm(fields.phoneNumber)){
            setIsAvailablePhoneNumber("The phone number must be a 10-digit number.");
            return;
        }
        // Check user put the same value on password input and checkPassword input
        if(fields.password !== fields.checkPassword){
          setisAvaIlablePassword("Password is not matched!");
          // Reset password field to blank
          const tmp = { ...fields };
          tmp.password = "";
          tmp.checkPassword = "";
          setFields(tmp);
          return;
        }
        else{
          setisAvaIlablePassword(null);
        }
        if(!passwordIsStrong(fields.password)){
            return;
        }
        // If verified new account is already existed.
        if(isExist === false) {
            // console.log(fields);
          // Navigate to the login page.
          await axios.post("http://localhost:4000/api/users", fields);
          navigate("/login");
          window.alert("Your account is successfully created!");
        return;
        }
        else{
          // Set error message.
          setIsAvailableUser("Email is already existed");
          // Reset password field to blank
          const temp = { ...fields };
          temp.email = "";
          setFields(temp);
        }
    }
    useEffect(() => {
        refreshUsers();
    }, [])

    console.log(users);
    return(
        <div className = "signin-box">
            <div className = "signin-wrapper">
            <form onSubmit={createAccount}>
                <h1>Create Account</h1>
                {/* Input User Name */}
                <div className = "input-field">
                    <input type = "text" placeholder="User Name" required 
                    name="username" id="username"
                    value={fields.username} onChange={handleInputChange}/>
                    <FaUser className="icon"/>
                </div>
                {/* Input Email */}
                <div className = "input-field">
                    <input type = "text" placeholder="ex) Username@gmail.com" required 
                    name="email" id="email"
                    value={fields.email} onChange={handleInputChange}/>
                    <MdEmail className="icon"/>
                    {isAvailableUser !== null &&
                    <div className="errorMessage">
                        <span>{isAvailableUser}</span>
                    </div>
                    }
                </div>
                {/* Phone Number */}
                <div className = "input-field">
                    <input type = "text" inputMode="numeric" placeholder="Phone Number (10 digits)" required 
                    name="phoneNumber" id="phoneNumber"
                    value={fields.phoneNumber} onChange={handleInputChange}/>
                    <FaPhone className="icon"/>
                    {isAvailablePhoneNumber !== null &&
                    <div className="errorMessage">
                        <span>{isAvailablePhoneNumber}</span>
                    </div>
                    }
                </div>

                {/* Input Address */}
                <div className = "input-field">
                    <input type = "text" placeholder="Address" required 
                    name="address" id="address"
                    value={fields.address} onChange={handleInputChange}/>
                    <FaLocationDot className="icon"/>
                </div>
                {/* Input Email */}
                
                {/* Input Password */}
                <div className = "input-field">
                    <input type = "password" placeholder="Passsword" required 
                    name="password" id="password"
                    value={fields.password} onChange={handleInputChange}/>
                    <PiPassword className="icon"/>
                    {isStrong !== null &&
                    <div className="errorMessage">
                        <span>{isStrong}</span>
                    </div>
                    } 
                </div>

                {/* Check Password */}
                <div className = "input-field">
                    <input type = "password" placeholder="Check your password" required 
                    name="checkPassword" id="checkPassword"
                    value={fields.checkPassword} onChange={handleInputChange}/>
                    <FaCheck className="icon"/>
                    {isAvailablePassword !== null &&
                    <div className="errorMessage">
                        <span>{isAvailablePassword}</span>
                    </div>
                    } 
                </div>

                <button type = "submit" onClick = {setDate}>Create Account</button>
  
            </form>
        </div>
        </div>
    );
}
export default Signin;