import { useState, useEffect } from "react";
import { Switch, Route, Link } from "react-router-dom";
import axios from "axios";
import User from "./User";
import CreateAndEditUser from "./CreateAndEditUser";

export default function Users() {
  const [isLoaded, setIsLoaded] = useState(false);
  const [error, setError] = useState(null);
  const [users, setUsers] = useState([]);

  useEffect(() => {
    refreshUsers();
  }, []);

  const refreshUsers = async () => {
    setIsLoaded(false);
    setError(null);

    // Using Axios with async.
    try {
      const result = await axios.get("http://localhost:4000/api/users");
      setUsers(result.data);
    } catch(e) {
      setError(e);
    } finally {
      setIsLoaded(true);
    }
  };

  const deleteUser = async (id) => {
    if(!window.confirm(`Are you sure you want to delete User ID ${id} ?`))
      return;

    // Using Axios with async.
    try {
      const result = await axios.delete(`http://localhost:4000/api/users/${id}`);

      // Check result, purposely not checked here for simplicity.
      // Result is logged to console for demostration purposes.
      console.log(result);

      // Refresh view.
      // NOTE: Could alternatively just delete the row / object from the state that was removed.
      await refreshUsers();
    } catch(e) {
      setError(e);
    }
  };

  if(error) {
    return <div>Error: {error.message}</div>;
  }
  if(!isLoaded) {
    return <div>Loading...</div>;
  }

  return (
    <Switch>
      <Route path={["/users/create", "/users/edit/:id"]}>
        <CreateAndEditUser refreshUsers={refreshUsers} />
      </Route>
      <Route path="/users/:id">
        <User />
      </Route>
      <Route path="/users">
        <h1>Users</h1>
        <p>
          <Link to="/users/create">Create New</Link>
        </p>
        <table className="table table-hover">
          <thead>
            <tr>
              <th>User ID</th>
              <th>First Name</th>
              <th>Last Name</th>
              <th></th>
              <th></th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            {users.map(x => (
              <tr key={x.user_id}>
                <td>{x.user_id}</td>
                <td>{x.first_name}</td>
                <td>{x.last_name}</td>
                <td><Link to={{ pathname: `/users/${x.user_id}`, state: x }}>Details</Link></td>
                <td><Link to={{ pathname: `/users/edit/${x.user_id}`, state: x }}>Edit</Link></td>
                <td>
                  <button className="btn btn-danger" onClick={() => deleteUser(x.user_id)}>Delete</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </Route>
    </Switch>
  );
}
