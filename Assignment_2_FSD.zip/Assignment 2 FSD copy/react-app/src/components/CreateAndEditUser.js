import { useState } from "react";
import { useHistory, useParams, useLocation } from "react-router-dom";
import axios from "axios";
import { Link } from "react-router-dom";

export default function CreateAndEditUser(props) {
  const history = useHistory();
  const { id } = useParams();
  const { state } = useLocation();

  const [fields, setFields] = useState({
    firstName: state ? state.first_name : "",
    lastName: state ? state.last_name : ""
  });
  const [errors, setErrors] = useState({ });

  const handleValidation = () => {
    const errorsToSet = { };

    // First name.
    let key = "firstName";
    if(!fields[key])
      errorsToSet[key] = "First name cannot be empty.";
    else if(!fields[key].match(/^[A-Za-z]+$/))
      errorsToSet[key] = "First name can only contain letters.";

    // Last name.
    key = "lastName";
    if(!fields[key])
      errorsToSet[key] = "Last name cannot be empty.";
    else if(!fields[key].match(/^[A-Za-z]+$/))
      errorsToSet[key] = "Last name can only contain letters.";

    setErrors(errorsToSet);

    // Only return true if no errors.
    return Object.keys(errorsToSet).length === 0;
  };
  // Generic change handler.
  const handleInputChange = (event) => {
    setFields({ ...fields, [event.target.name]: event.target.value });
  };
  const handleSubmit = async (event) => {
    event.preventDefault();

    if(!handleValidation())
      return;

    // Using Axios with async.
    try {
      // Update the user if id exists, otherwise create a new user.
      const result = id ?
        await axios.put(`http://localhost:4000/api/users/${id}`, fields) :
        await axios.post("http://localhost:4000/api/users", fields);

      // Check result, purposely not checked here for simplicity.
      // Result is logged to console for demostration purposes.
      console.log(result);

      // Before navigating start updating the parent.
      props.refreshUsers();

      // Navigate to the all users page.
      history.push("/users");
    } catch(e) {
      setErrors({ errorMessage: e.message });
    }
  };

  return (
    <div>
      <div>
        <h1>{id ? "Edit" : "Create"} User</h1>
        <hr />
        <div className="row">
          <div className="col-md-4">
            <form onSubmit={handleSubmit}>
              {id &&
                <div className="form-group row">
                  <label htmlFor="userID" className="col-sm-4 col-form-label">User ID</label>
                  <div className="col-sm-8">
                    <input readOnly id="userID" className="form-control-plaintext" value={id} />
                  </div>
                </div>
              }
              <div className="form-group">
                <label htmlFor="firstName" className="control-label">First Name</label>
                <input name="firstName" id="firstName" className="form-control"
                  value={fields.firstName} onChange={handleInputChange} />
                {errors.firstName &&
                  <span className="text-danger">{errors.firstName}</span>
                }
              </div>
              <div className="form-group">
                <label htmlFor="lastName" className="control-label">Last Name</label>
                <input name="lastName" id="lastName" className="form-control"
                  value={fields.lastName} onChange={handleInputChange} />
                {errors.lastName &&
                  <span className="text-danger">{errors.lastName}</span>
                }
              </div>
              <div className="form-group">
                <input type="submit" className="btn btn-primary" value={id ? "Update" : "Create"} />
              </div>
              {errors.errorMessage &&
                <div className="form-group">
                  <span className="text-danger">{errors.errorMessage}</span>
                </div>
              }
            </form>
          </div>
        </div>
      </div>
      <div>
        <Link to="/users">Back to List</Link>
      </div>
    </div>
  );
}
