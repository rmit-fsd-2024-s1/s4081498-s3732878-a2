import { FaStar } from "react-icons/fa";
import React, { useState, useEffect } from "react";
import "./Star.css"
import axios from "axios";
import {getUser} from "../data/repository";


const Star = (props) => {

  const [rating, setRating] = useState(null);
  const [hover, setHover] = useState(null);

  // const [isEditing, setIsEditing] = useState(false);
  const [comment, setComment] = useState("");

  const [user, setUser] = useState(getUser());
  const [date, setDate] = useState();

  const handleInputChange = (event) => {
    // const name = event.target.name;
    const value = event.target.value;
    const temp = value;
    setComment(temp);
}
  const saveComment = async (e) => {
    e.preventDefault();

    if(rating !== null && comment !== ""){
      await axios.post("http://localhost:4000/api/reviews", 
      {item_id: parseInt(props.itemID), user: user, comment: comment, rate: parseInt(rating), date: date});
      alert("Review is updated.");
      props.refreshReviews();
    }
  };

  const returnDate = () =>{
    const now = new Date();
    const year = now.getFullYear();
    const month = now.getMonth() + 1;
    const day = now.getDate();
    const hours = now.getHours();
    const minutes = now.getMinutes();
    const dateString = `${year}-${month < 10 ? '0' + month : month}-${day < 10 ? '0' + day : day} ${hours < 10 ? '0' + hours : hours}:${minutes < 10 ? '0' + minutes : minutes}`;
    setDate(dateString);
  } 

  useEffect(() => {
    returnDate();
  }, [])


  return (
      <div className="rating-wrapper">
        <div className="star-rating">
          {[...Array(5)].map((star,i)=>{
            const ratingValue = i+1;

            return <label>
              <input type="radio" name = "rating" value={ratingValue} onClick={()=>setRating(ratingValue)}></input>
              <FaStar className = "star" color ={ratingValue <= (hover || rating) ? "#ffc107" : "#e4e5e9"} size={80}  onMouseEnter={()=>setHover(ratingValue)} onMouseLeave={()=> setHover(null)}/>
            </label>
         })}
          <div>
            <form onSubmit={saveComment}>
            <label>
              Review Comment:{""}
              <input type = "text" placeholder="Your comment here..." 
                  name="comment" id="comment"
                  value={comment} onChange={handleInputChange}
              />
            </label>
            <button type="submit">Save Review</button>
          </form>
      </div>
      </div>
      </div>
  );
};


export default Star;