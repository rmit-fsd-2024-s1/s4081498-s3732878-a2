import React, {useState} from 'react';
import { IoStar } from "react-icons/io5";
import "./CommentStyles.css";


function Comment(props){
    // console.log(props);
    return(
        <div className='comment-wrapper'>
            <p> <IoStar />  {props.review.rate} | {props.review.user} | {props.review.date}</p>
            <p>{props.review.comment}</p>

        </div>
    );
}
export default Comment;