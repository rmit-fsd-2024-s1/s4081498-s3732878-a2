import React, {useState, useEffect} from 'react';
import "./CardStyles.css";
import { FaCartShopping } from "react-icons/fa6";
import { FaPlus } from "react-icons/fa";
import { FaMinus } from "react-icons/fa";
// import { addToCart, getSpecial } from "../data/repository";
import { Link } from "react-router-dom";
import { RiDiscountPercentFill } from "react-icons/ri";
import axios from "axios";


function Card(props){
    const item = props.item;
    const [quantity, setQuantity] = useState(1);
    const [specials, setSpecials] = useState([]);
    const [isLoaded, setIsLoaded] = useState(false);
    const [error, setError] = useState(null);
    const [cart, setCart] = useState([]);
    let isSpecial = false;

    const refreshSpecials = async () => {
        setIsLoaded(false);
        setError(null);
        // Using Axios with async.
        try {
          const result = await axios.get("http://localhost:4000/api/specials");
          setSpecials(result.data);
        } catch(e) {
          setError(e);
        } finally {
          setIsLoaded(true);
        }
    };
    const refreshCarts = async () => {
        setIsLoaded(false);
        setError(null);
        // Using Axios with async.
        try {
          const result = await axios.get("http://localhost:4000/api/carts");
          setCart(result.data);
        } catch(e) {
          setError(e);
        } finally {
          setIsLoaded(true);
        }
    };
    const quantityPlus = () =>{
        const prevQuantity = quantity;
        setQuantity(prevQuantity + 1);
    };
    const quantityMinus = () =>{
        const prevQuantity = quantity;
        if(prevQuantity > 1) setQuantity(prevQuantity - 1);
    };
    const toCart = async () => {
        const cartItem = cart.filter(cart => cart.name === item.name);
        console.log(cartItem.length);
        if(cartItem.length === 0){
            console.log("add");
            if(isSpecial){
                await axios.post("http://localhost:4000/api/carts", {name: item.name, description: item.description, quantity: quantity, 
            price: (item.price * (1 - props.discountRate/100)), imageSrc: item.imageSrc});
            }
            else{
                await axios.post("http://localhost:4000/api/carts", {name: item.name, description: item.description, quantity: quantity, 
            price: item.price, imageSrc: item.imageSrc});
            }
        }
        else{
            console.log("update");
            if(isSpecial){
                await axios.put(`http://localhost:4000/api/carts/${cartItem[0].item_id}`, {name: item.name, description: item.description, quantity: quantity + cartItem[0].quantity, 
            price: (item.price * (1 - props.discountRate/100)), imageSrc: item.imageSrc});
            }
            else{
                await axios.put(`http://localhost:4000/api/carts/${cartItem[0].item_id}`, {name: item.name, description: item.description, quantity: quantity + cartItem[0].quantity, 
            price: item.price, imageSrc: item.imageSrc});
            }
        }
        
        alert("Add to cart successfully!");
    };
    const isSpecialItem = () => {
        for(let i = 0; i < specials.length; i++){
            if(item.name === specials[i].name){
                isSpecial = true;
            }
        }
    }
    useEffect(() => {
        refreshSpecials();
        refreshCarts();
    }, []);
    
    isSpecialItem();

    return(
        <div className="card-wrapper">
            
                <Link to = {`/detail/${item.item_id}`}><img src = {item.imageSrc} alt ="Image"/></Link>
                <button id = "cart-icon" onClick={toCart}><FaCartShopping/></button>
                <div id={isSpecial ? 'discount-icon' : 'non-discount-icon'}>
                    <div>
                        {isSpecial && < RiDiscountPercentFill/>}
                    </div>
                </div>
                <h1>{item.name}</h1>
                <p>{item.description}</p>
                <div className="card-buttons">
                    <button onClick={quantityMinus}><span><FaMinus/></span></button>
                    <p>{quantity}</p>
                    <button onClick={quantityPlus}><span><FaPlus/></span></button>
                    {isSpecial ? 
                        <p style={{ color: "red" }}>{`$${(item.price * (1 - props.discountRate/100) * quantity).toFixed(1)}`}</p>
                        :
                        <p>{`$${(item.price * quantity).toFixed(1)}`}</p>
                    }
                </div>
        </div>
    );
}

export default Card;