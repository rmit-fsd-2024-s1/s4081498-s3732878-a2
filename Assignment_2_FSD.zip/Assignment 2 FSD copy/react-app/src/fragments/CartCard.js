import React, {useState, useEffect} from 'react';
import "./CartCardStyles.css";
import { FaPlus } from "react-icons/fa";
import { FaMinus } from "react-icons/fa";
import { RiDeleteBin5Line } from "react-icons/ri";

function CartCard(props){
    const [item, setItem] = useState(props.item);
    const remove=()=>{
        props.removeItem(item.name);
    }
    const plus = () =>{
        props.quantityPlus(item.name);
    }
    const minus = () =>{
        props.quantityMinus(item.name);
    }
    useEffect(()=>{
        setItem(props.item);
    }, [props]);
    

    return(
        <div className="cart-card-wrapper">
            <img src = {item.imageSrc} alt ="Image"/>
            <div className='cart-card-inner'>
                <h1>{item.name}</h1>
                <p id="description">{item.description}</p>
                <p id="price">{`Price: $${(item.price * item.quantity).toFixed(1)}`}</p>
                <div className="cart-card-buttons">
                    <button onClick={minus}><FaMinus/></button>
                    <p>{item.quantity}</p>
                    <button onClick={plus}><FaPlus/></button>
                    <button id="delete-button" onClick = {remove}><RiDeleteBin5Line/></button>
                </div>
            </div>
        </div>
    );
}

export default CartCard;
