import React, { useState } from "react";
import './ItemListStyles.css';
import Card from './Card.js';
import { getDiscount } from "../data/repository.js";

function ItemList(props){
    const discountRate = getDiscount();
    return(
        <div className="list-wrapper">
            {props.items.map((item, index) => (
                <Card key={index} item={item} discountRate = {discountRate} />
            ))}
        </div>
    );
}

export default ItemList;