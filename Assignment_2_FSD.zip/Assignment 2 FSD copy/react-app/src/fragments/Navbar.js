import "./NavbarStyles.css";
import React, { useState } from 'react';
import { Link } from "react-router-dom";

function Navbar(props){
    const [barState, setBarState] = useState(false);

    const iconClick = () => {
        if(barState === true) setBarState(false)
        else setBarState(true)
    }

    return(
        <div>
            <div id = "header">

                {/* Title */}
                <h1 id = "title">SOIL</h1>
                {/* Hamburger Menu */}
                <div id = "hamburgerIcon" onClick = {iconClick}>
                    <i className="material-symbols-outlined"> {barState ? "close" : "menu"} </i>
                </div>
            </div>
            <nav>
                {/* NavBar Items */}
                <div>
                    <ul id="navbarItems" className = {barState ? "#navbarItems active" : "#navbarItems"}>
                        <li><Link to="/">Home</Link></li>
                        <li><Link to="/shop">Shop</Link></li>
                        <li><Link to="/about">About</Link></li>
                        <li><Link to="/review">Review</Link></li>
                        {props.username === null ? 
                            <li><Link to={"/login"}>Login</Link></li>
                            :
                            <>
                                <li><Link to={"/profile"}>My Profile</Link></li>
                                <li><Link to={"/cart"}>My Cart</Link></li>
                                {/* <li><Link to={"/diet"}>My Diet</Link></li> */}
                                <li><Link to={"/"} onClick={props.logoutUser}>Logout</Link></li>
                            </>
                        }
                    </ul>
                </div>
            </nav>
        </div>
    );
}

export default Navbar;