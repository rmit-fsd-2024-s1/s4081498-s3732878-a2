module.exports = (express, app) => {
    const controller = require("../controllers/cart.controller.js");
    const router = express.Router();
  
    // Select all carts.
    router.get("/", controller.all);
  
    // Select a single cart with id.
    router.get("/:id", controller.one);
  
    // Create a new cart.
    router.post("/", controller.create);
  
    // Update a cart with id.
    router.put("/:id", controller.update);
  
    // Delete a cart with id.
    router.delete("/:id", controller.remove);
  
    // Add routes to server.
    app.use("/api/carts", router);
  };