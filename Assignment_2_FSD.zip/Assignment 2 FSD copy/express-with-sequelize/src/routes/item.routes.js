module.exports = (express, app) => {
  const controller = require("../controllers/item.controller.js");
  const router = express.Router();

  // Select all items.
  router.get("/", controller.all);

  // Select a single item with id.
  router.get("/:id", controller.one);

  // Create a new item.
  router.post("/", controller.create);

  // Update a item with id.
  router.put("/:id", controller.update);

  // Delete a item with id.
  router.delete("/:id", controller.remove);

  // Add routes to server.
  app.use("/api/items", router);
};