module.exports = (express, app) => {
    const controller = require("../controllers/special.controller.js");
    const router = express.Router();
  
    // Select all special.
    router.get("/", controller.all);
  
    // Select a single special with id.
    router.get("/:id", controller.one);
  
    // Create a new special.
    router.post("/", controller.create);
  
    // Update a special with id.
    router.put("/:id", controller.update);
  
    // Delete a special with id.
    router.delete("/:id", controller.remove);
  
    // Add routes to server.
    app.use("/api/specials", router);
  };