module.exports = (sequelize, DataTypes) =>
  sequelize.define("cart", {
    item_id: {
      type: DataTypes.INTEGER,
      autoIncrement: true,
      primaryKey: true
    },
    name: {
      type: DataTypes.STRING(40),
      allowNull: false
    },
    description: {
      type: DataTypes.STRING(200),
      allowNull: false
    },
    quantity: {
        type: DataTypes.INTEGER,
        allowNull: false
      },
    price: {
        type: DataTypes.FLOAT,
        allowNull: false
    },  
    imageSrc: {
      type: DataTypes.STRING(1000),
      allowNull: false
    },
    
  }, {
    // Don't add the timestamp attributes (updatedAt, createdAt).
    timestamps: false
  });