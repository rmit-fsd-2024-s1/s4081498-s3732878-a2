module.exports = {
  HOST: "rmit.australiaeast.cloudapp.azure.com",
  USER: "s3732878_fsd_a2",
  PASSWORD: "nci5772hj#",
  DB: "s3732878_fsd_a2",
  DIALECT: "mysql"
};
