const db = require("../database");

// Select all cart from the database.
exports.all = async (req, res) => {
  const carts = await db.cart.findAll();

  res.json(carts);
};

// Select one cart from the database.
exports.one = async (req, res) => {
  const id = req.params.id;

  const cart = await db.cart.findByPk(id);

  res.json(cart);
};

// Create a cart in the database.
exports.create = async (req, res) => {
  const cart = await db.cart.create({
    name: req.body.name,
    description: req.body.description,
    quantity: req.body.quantity,
    price: req.body.price,
    imageSrc: req.body.imageSrc,
  });

  return res.json(cart);
};

// Update a cart in the database.
exports.update = async (req, res) => {
  const id = req.params.id;
  const cart = await db.cart.findByPk(id);
  
  cart.name = req.body.name;
  cart.description = req.body.description;
  cart.quantity = req.body.quantity;
  cart.price = req.body.price;
  cart.imageSrc = req.body.imageSrc;

  await cart.save();

  return res.json(cart);
};

// Remove a cart from the database.
exports.remove = async (req, res) => {
  const id = req.params.id;
  console.log("test");
  let removed = false;

  const cart = await db.cart.findByPk(id);
  if(cart !== null) {
    await cart.destroy();
    removed = true;
  }

  return res.json(removed);
};
