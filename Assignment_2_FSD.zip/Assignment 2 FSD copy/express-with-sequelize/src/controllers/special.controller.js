const db = require("../database");

// Select all special from the database.
exports.all = async (req, res) => {
  const specials = await db.special.findAll();

  res.json(specials);
};

// Select one special from the database.
exports.one = async (req, res) => {
  const id = req.params.id; //

  const special = await db.special.findByPk(id);

  res.json(special);
};

// Create a user in the database.
exports.create = async (req, res) => {
  const special = await db.special.create({
    first_name: req.body.firstName, //
    last_name: req.body.lastName    //
  });

  return res.json(special);
};

// Update a special in the database.
exports.update = async (req, res) => {
  const id = req.params.id;

  const special = await db.special.findByPk(id);

  user.first_name = req.body.firstName; //
  user.last_name = req.body.lastName;   //

  await special.save();

  return res.json(special);
};

// Remove a special from the database.
exports.remove = async (req, res) => {
  const id = req.params.id;

  let removed = false;

  const special = await db.special.findByPk(id);
  if(special !== null) {
    await special.destroy();
    removed = true;
  }

  return res.json(removed);
};
