const db = require("../database");

// Select all users from the database.
exports.all = async (req, res) => {
  const users = await db.user.findAll();

  res.json(users);
};

// Select one user from the database.
exports.one = async (req, res) => {
  const id = req.params.id;

  const user = await db.user.findByPk(id);

  res.json(user);
};

// Create a user in the database.
exports.create = async (req, res) => {
  const user = await db.user.create({
    address: req.body.address,
    date: req.body.date,
    email: req.body.email,
    password: req.body.password,
    phoneNumber: req.body.phoneNumber,
    username: req.body.username,
  });

  return res.json(user);
};

// Update a user in the database.
exports.update = async (req, res) => {
  const id = req.params.id;
  console.log(id);
  const user = await db.user.findByPk(id);
  
  user.address = req.body.address;
  user.date = req.body.date;
  user.email = req.body.email;
  user.password = req.body.password;
  user.phoneNumber = req.body.phoneNumber;
  user.username = req.body.username;

  await user.save();

  return res.json(user);
};

// Remove a user from the database.
exports.remove = async (req, res) => {
  const id = req.params.id;

  let removed = false;

  const user = await db.user.findByPk(id);
  if(user !== null) {
    await user.destroy();
    removed = true;
  }

  return res.json(removed);
};
